let allSymbols = [];

// Load core KB
async function loadSymbolJSON(url) {
    const resp = await fetch(url);
    return await resp.json();
}

function createSymbolBox(sym) {
    const div = document.createElement('div');
    div.className = 'symbol-box';
    div.innerHTML = `<h2>${sym.symbol}</h2>
                     <p>${sym.phrase}</p>
                     <p>C: ${sym.C}</p>
                     <p>VB6: ${sym.VB6}</p>
                     <p>ASM: ${sym.ASM}</p>
                     <div class="references">
                       <h3>References</h3>
                       <ul>
                         <li><a href="${sym.MSDN_ref}" target="_blank">MSDN</a></li>
                         <li><a href="${sym.Borland_ref}" target="_blank">Borland</a></li>
                       </ul>
                     </div>
                     <div class="diagram">
                       <img src="${sym.image}" alt="${sym.symbol} diagram">
                     </div>`;
    return div;
}

function displaySymbols(symbols) {
    const container = document.getElementById('symbol-list');
    container.innerHTML = '';
    symbols.forEach(sym => {
        container.appendChild(createSymbolBox(sym));
    });
}

// Load core KB
loadSymbolJSON('kb/symbols.json').then(symbols => {
    symbols.forEach(sym => {
        sym.MSDN_ref = `https://docs.microsoft.com/en-us/search/?q=${sym.symbol}`;
        sym.Borland_ref = `https://docwiki.embarcadero.com/Libraries/BorlandCBuilder/en/${sym.symbol}`;
        sym.image = `resources/images/${sym.symbol}.png`;
    });
    allSymbols = symbols;
    displaySymbols(allSymbols);
});

// Local expansion loader
function loadExpansion() {
    const input = document.getElementById('expansionLoader');
    if (!input.files.length) return;
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = async function() {
        const zip = await JSZip.loadAsync(reader.result);
        if(zip.files['symbols.json']) {
            const jsonStr = await zip.files['symbols.json'].async('string');
            const expansionSymbols = JSON.parse(jsonStr);
            mergeSymbols(expansionSymbols);
            displaySymbols(allSymbols);
        }
    };
    reader.readAsArrayBuffer(file);
}

// Online expansion loader (OneDrive)
const ONE_DRIVE_BASE = 'https://onedrive.live.com/download?cid=YOUR_CID&resid=YOUR_FILE_ID&authkey=YOUR_AUTH';
async function fetchOnlineExpansion(filename) {
    const url = `${ONE_DRIVE_BASE}/${filename}`;
    try {
        const resp = await fetch(url);
        const zipArrayBuffer = await resp.arrayBuffer();
        const zip = await JSZip.loadAsync(zipArrayBuffer);
        if(zip.files['symbols.json']) {
            const jsonStr = await zip.files['symbols.json'].async('string');
            const expansionSymbols = JSON.parse(jsonStr);
            mergeSymbols(expansionSymbols);
            displaySymbols(allSymbols);
        }
    } catch(e) { console.error("Failed to fetch expansion:", e); }
}

// Merge symbols (seed-aware)
function mergeSymbols(newSymbols) {
    newSymbols.forEach(expSym => {
        const index = allSymbols.findIndex(s => s.id === expSym.id);
        if(index !== -1) {
            if(expSym.flags & 0xFF) allSymbols[index] = expSym;
        } else {
            allSymbols.push(expSym);
        }
    });
}
