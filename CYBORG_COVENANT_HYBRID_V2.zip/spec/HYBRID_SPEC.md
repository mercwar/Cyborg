Hybrid English is a control surface.
